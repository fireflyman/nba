require 'rails'

module Authorization
  class RailsEngine < Rails::Engine
  end
end